from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib
import sqlite3
import os
from datetime import datetime
import plotly.express as px
import plotly.utils
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

# Ensure DB is initialized
def init_db():
    conn = sqlite3.connect('user_data.db')
    c = conn.cursor()
    
    # Drop existing tables if they exist
    c.execute('DROP TABLE IF EXISTS user_data')
    c.execute('DROP TABLE IF EXISTS user_recommendations')
    
    # Create user_data table with proper schema
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            phone TEXT,
            email TEXT,
            age INTEGER,
            gender TEXT,
            occupation TEXT,
            sleep_hours INTEGER,
            exercise_hours INTEGER,
            phone_usage INTEGER,
            work_pressure INTEGER,
            mood_swings TEXT,
            meal_timing TEXT,
            predicted_stress_level TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create table for user recommendations
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_recommendations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_email TEXT,
            recommendation TEXT,
            completed BOOLEAN DEFAULT FALSE,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

def get_user_history(email):
    conn = sqlite3.connect('user_data.db')
    try:
        # First check if the user has any data
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM user_data WHERE email = ?', (email,))
        count = cursor.fetchone()[0]
        
        if count == 0:
            print(f"No data found for email: {email}")
            return pd.DataFrame()
            
        df = pd.read_sql_query('''
            SELECT predicted_stress_level, timestamp, 
                   sleep_hours, exercise_hours, work_pressure, phone_usage
            FROM user_data 
            WHERE email = ? 
            ORDER BY timestamp DESC
            LIMIT 10
        ''', conn, params=(email,))
        
        if not df.empty:
            # Convert timestamp to datetime if it's not already
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            # Format timestamp for display
            df['formatted_date'] = df['timestamp'].dt.strftime('%Y-%m-%d %H:%M')
        
        return df
    except Exception as e:
        print(f"Error getting user history: {str(e)}")
        return pd.DataFrame()
    finally:
        conn.close()

def generate_stress_trends(email):
    try:
        df = get_user_history(email)
        if len(df) > 0:
            # Convert stress levels to numeric values
            stress_map = {'Low': 1, 'Medium': 2, 'High': 3}
            df['stress_numeric'] = df['predicted_stress_level'].map(stress_map)
            
            # Create stress level trend
            fig_stress = px.line(df, 
                               x='formatted_date', 
                               y='stress_numeric',
                               title='Your Stress Level History',
                               labels={
                                   'formatted_date': 'Date',
                                   'stress_numeric': 'Stress Level'
                               })
            fig_stress.update_layout(
                yaxis=dict(ticktext=['Low', 'Medium', 'High'],
                          tickvals=[1, 2, 3]),
                hovermode='x unified'
            )
            
            # Create lifestyle factors correlation
            fig_factors = px.scatter_matrix(
                df,
                dimensions=['sleep_hours', 'exercise_hours', 
                          'work_pressure', 'phone_usage'],
                title='Lifestyle Factors Relationships',
                labels={
                    'sleep_hours': 'Sleep (hours)',
                    'exercise_hours': 'Exercise (hours)',
                    'work_pressure': 'Work Pressure (1-10)',
                    'phone_usage': 'Phone Usage (hours)'
                }
            )
            fig_factors.update_layout(
                height=600,
                showlegend=False
            )
            
            # Calculate statistics
            stats = {
                'total_entries': len(df),
                'avg_stress': df['stress_numeric'].mean(),
                'avg_sleep': df['sleep_hours'].mean(),
                'avg_exercise': df['exercise_hours'].mean(),
                'avg_work_pressure': df['work_pressure'].mean(),
                'avg_phone_usage': df['phone_usage'].mean(),
                'latest_prediction': df.iloc[0]['predicted_stress_level'] if not df.empty else 'N/A',
                'stress_distribution': df['predicted_stress_level'].value_counts().to_dict()
            }
            
            return jsonify({
                'stress_trend': json.loads(fig_stress.to_json()),
                'factors_correlation': json.loads(fig_factors.to_json()),
                'statistics': stats
            })
            
        return jsonify({
            'error': 'No history found for this user',
            'statistics': {
                'total_entries': 0,
                'latest_prediction': 'N/A'
            }
        })
        
    except Exception as e:
        print(f"Error generating trends: {str(e)}")
        return jsonify({
            'error': 'Error generating visualizations',
            'details': str(e)
        })

def send_email_report(email, stress_level, recommendations):
    # Email configuration
    sender_email = "your-email@gmail.com"  # Replace with your email
    password = "your-app-password"  # Replace with your app password
    
    msg = MIMEMultipart()
    msg['Subject'] = 'Your Stress Analysis Report'
    msg['From'] = sender_email
    msg['To'] = email
    
    body = f"""
    Hello,
    
    Here's your stress analysis report:
    
    Current Stress Level: {stress_level}
    
    Recommendations:
    {recommendations}
    
    Stay healthy!
    """
    
    msg.attach(MIMEText(body, 'plain'))
    
    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, password)
            server.send_message(msg)
        return True
    except Exception as e:
        print(f"Error sending email: {str(e)}")
        return False

def get_personalized_recommendations(email, current_stress_level):
    history = get_user_history(email)
    recommendations = []
    
    if len(history) > 0:
        avg_sleep = history['sleep_hours'].mean()
        avg_exercise = history['exercise_hours'].mean()
        avg_work_pressure = history['work_pressure'].mean()
        avg_phone_usage = history['phone_usage'].mean()
        
        if avg_sleep < 7:
            recommendations.append("Try to increase your sleep duration to at least 7 hours")
        if avg_exercise < 2:
            recommendations.append("Consider increasing your weekly exercise hours")
        if avg_work_pressure > 7:
            recommendations.append("Look into stress management techniques for work")
        if avg_phone_usage > 5:
            recommendations.append("Consider reducing daily phone usage")
            
    return recommendations

init_db()

@app.route('/')
def home():
    try:
        return render_template('index.html')
    except Exception as e:
        print(f"Error rendering template: {str(e)}")
        return f"Error: {str(e)}", 500

@app.route('/predict', methods=['POST'])
def predict():
    if request.method != 'POST':
        return render_template('error.html', error="Method not allowed")

    try:
        # Load model and encoders
        try:
            model = joblib.load('stress_model.pkl')
            gender_encoder = joblib.load('gender_encoder.pkl')
            occupation_encoder = joblib.load('occupation_encoder.pkl')
            mind_swing_encoder = joblib.load('mind_swing_encoder.pkl')
            meal_timing_encoder = joblib.load('meal_timing_encoder.pkl')
            stress_encoder = joblib.load('stress_encoder.pkl')
        except Exception as e:
            print(f"Error loading models: {e}")
            return render_template('error.html', error="Could not load prediction models")

        # Form data validation and processing
        data = request.form
        if not data:
            return render_template('error.html', error="No form data received")

        # Define required fields with validation rules
        field_validations = {
            'Name': {'required': True, 'min_length': 2},
            'Mobile': {'required': True, 'pattern': r'^\d{10}$'},
            'Email': {'required': True, 'pattern': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'},
            'Age': {'required': True, 'type': int, 'min': 1, 'max': 120},
            'Gender': {'required': True, 'values': ['Male', 'Female', 'Other']},
            'Occupation': {'required': True},
            'SleepHours': {'required': True, 'type': int, 'min': 0, 'max': 24},
            'ExerciseHours': {'required': True, 'type': int, 'min': 0, 'max': 24},
            'WorkPressure': {'required': True, 'type': int, 'min': 0, 'max': 10},
            'PhoneUsageHours': {'required': True, 'type': int, 'min': 0, 'max': 24},
            'MoodSwings': {'required': True},
            'MealsOnTime': {'required': True}
        }

        # Process and validate form data
        try:
            import re
            processed_data = {}

            for field, rules in field_validations.items():
                value = data.get(field, '').strip()

                # Check required fields
                if rules.get('required') and not value:
                    return render_template('error.html', 
                                        error=f"Field '{field}' is required")

                # Validate string length if specified
                if 'min_length' in rules and len(value) < rules['min_length']:
                    return render_template('error.html', 
                                        error=f"Field '{field}' must be at least {rules['min_length']} characters long")

                # Validate pattern if specified
                if 'pattern' in rules and not re.match(rules['pattern'], value):
                    return render_template('error.html', 
                                        error=f"Invalid format for field '{field}'")

                # Validate numeric fields
                if rules.get('type') == int:
                    try:
                        value = int(value)
                        if 'min' in rules and value < rules['min']:
                            return render_template('error.html', 
                                                error=f"Field '{field}' must be at least {rules['min']}")
                        if 'max' in rules and value > rules['max']:
                            return render_template('error.html', 
                                                error=f"Field '{field}' must not exceed {rules['max']}")
                    except ValueError:
                        return render_template('error.html', 
                                            error=f"Field '{field}' must be a valid number")

                # Validate enum values if specified
                if 'values' in rules and value not in rules['values']:
                    return render_template('error.html', 
                                        error=f"Invalid value for field '{field}'")

                processed_data[field] = value

            # Assign validated data to variables
            name = processed_data['Name']
            phone = processed_data['Mobile']
            email = processed_data['Email']
            age = int(processed_data['Age'])
            gender = processed_data['Gender']
            occupation = processed_data['Occupation']
            sleep_hours = int(processed_data['SleepHours'])
            exercise_hours = int(processed_data['ExerciseHours'])
            work_pressure = int(processed_data['WorkPressure'])
            phone_usage = int(processed_data['PhoneUsageHours'])
            mind_swing = processed_data['MoodSwings']
            meal_timing = processed_data['MealsOnTime']

            print(f"Successfully processed form data: Age={age}, Gender={gender}, "
                  f"Occupation={occupation}, Sleep={sleep_hours}, Exercise={exercise_hours}, "
                  f"Work Pressure={work_pressure}, Phone Usage={phone_usage}, "
                  f"Mind Swing={mind_swing}, Meal Timing={meal_timing}")

        except Exception as e:
            print(f"Error processing form data: {str(e)}")
            return render_template('error.html', 
                                error=f"Error processing form data: {str(e)}")

        print("Creating DataFrame for prediction...")
        # Prediction input
        input_df = pd.DataFrame([{
            'Age': age,
            'Gender': gender,
            'Occupation': occupation,
            'Sleep_Hours': sleep_hours,
            'Exercise_Hours': exercise_hours,
            'Work_Pressure': work_pressure,
            'Phone_Usage': phone_usage,
            'Mind_Swing': mind_swing,
            'Meal_Timing': meal_timing
        }])
        print("DataFrame created:", input_df)

        try:
            print("Transforming features...")
            # Transform the input features
            print("Original Gender values:", input_df['Gender'].values)
            input_df['Gender'] = gender_encoder.transform(input_df['Gender'].values)
            print("Transformed Gender values:", input_df['Gender'].values)
            
            print("Original Occupation values:", input_df['Occupation'].values)
            input_df['Occupation'] = occupation_encoder.transform(input_df['Occupation'].values)
            print("Transformed Occupation values:", input_df['Occupation'].values)
            
            print("Original Mind_Swing values:", input_df['Mind_Swing'].values)
            input_df['Mind_Swing'] = mind_swing_encoder.transform(input_df['Mind_Swing'].values)
            print("Transformed Mind_Swing values:", input_df['Mind_Swing'].values)
            
            print("Original Meal_Timing values:", input_df['Meal_Timing'].values)
            input_df['Meal_Timing'] = meal_timing_encoder.transform(input_df['Meal_Timing'].values)
            print("Transformed Meal_Timing values:", input_df['Meal_Timing'].values)

            print("Making prediction...")
            # Predict
            prediction = model.predict(input_df)
            print("Raw prediction:", prediction)
            predicted_label = stress_encoder.inverse_transform(prediction)[0]
            print("Predicted label:", predicted_label)

            print("Saving to database...")
            # Save to SQLite DB
            conn = sqlite3.connect('user_data.db')
            try:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO user_data (
                        name, phone, email, age, gender, occupation,
                        sleep_hours, exercise_hours, phone_usage,
                        work_pressure, mood_swings, meal_timing, predicted_stress_level
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    name, phone, email, age, gender, occupation,
                    sleep_hours, exercise_hours, phone_usage,
                    work_pressure, mind_swing, meal_timing, predicted_label
                ))
                conn.commit()
                print("Database save successful")
            except sqlite3.Error as e:
                print(f"Database error: {e}")
                return render_template('error.html', error=f"Database error: {str(e)}")
            finally:
                conn.close()

            print("Returning prediction result...")
            return render_template('result.html', 
                                stress_level=predicted_label,
                                recommendations=[],  # Simplified for debugging
                                visualization_data=None,  # Simplified for debugging
                                email=email)

        except (ValueError, KeyError) as e:
            print(f"Error during prediction: {e}")
            return render_template('error.html', 
                                error=f"Invalid input data format: {str(e)}")
        except Exception as e:
            print(f"Unexpected error during prediction: {e}")
            import traceback
            print("Full traceback:")
            print(traceback.format_exc())
            return render_template('error.html', 
                                error=f"An unexpected error occurred: {str(e)}")

            # Get personalized recommendations
            try:
                recommendations = get_personalized_recommendations(email, predicted_label)
            except Exception as e:
                print(f"Error getting recommendations: {e}")
                recommendations = []
            
            # Generate visualizations
            try:
                visualization_data = generate_stress_trends(email)
            except Exception as e:
                print(f"Error generating visualizations: {e}")
                visualization_data = None
            
            # Send email report if stress level is High
            if predicted_label == 'High':
                try:
                    send_email_report(email, predicted_label, "\n".join(recommendations))
                except Exception as e:
                    print(f"Error sending email: {e}")

            return render_template('result.html', 
                                stress_level=predicted_label,
                                recommendations=recommendations,
                                visualization_data=visualization_data,
                                email=email)

    except Exception as e:
        print(f"Error in prediction route: {str(e)}")
        return render_template('error.html', 
                             error="An error occurred while processing your request. Please try again.")

@app.route('/user_history/<email>')
def user_history(email):
    try:
        # Get the user's history data
        history = get_user_history(email)
        if history.empty:
            return jsonify({'error': 'No history found'})
        
        # Generate visualizations
        visualizations = generate_stress_trends(email)
        if visualizations:
            return visualizations
        
        # If no visualizations, return raw data
        return jsonify(history.to_dict(orient='records'))
    except Exception as e:
        print(f"Error in user_history route: {str(e)}")
        return jsonify({'error': str(e)})

@app.route('/dashboard/<email>')
def dashboard(email):
    return render_template('dashboard.html', email=email)

if __name__ == '__main__':
    from waitress import serve
    print("Starting server at http://127.0.0.1:8501")
    serve(app, host='127.0.0.1', port=8501)
